import React, { useState, useEffect } from 'react';
import { X, Save, Link as LinkIcon, FolderOpen, Terminal, ChevronRight, ChevronDown, Sliders, Bug, Trash2, Database, Upload, CheckCircle2, AlertTriangle, FileJson, Clock, Share2, ArrowRight, Copy, SearchCode, HardDrive, Lock, Network, ArrowLeft, CloudCog, FileText, Activity } from 'lucide-react';
import { loadSettings, saveSettings, exportBackupData, importBackupData, getLastBackupInfo, saveLastBackupInfo, BackupInfo } from '../services/csvService';
import { getLogs, clearLogs, addLog, testProxyConnection } from '../services/syncService';
import { AppSettings } from '../types';
import { STORAGE_KEY_NOTE } from '../constants';
import { FilePicker } from '@capawesome/capacitor-file-picker';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  hideLogs?: boolean;
  onSave?: (settings: AppSettings) => void;
  onDataRestored?: () => void;
}

interface BackupSuccessState {
    isOpen: boolean;
    mode: 'EXPORT' | 'IMPORT';
    filename: string;
    resultLabel: string;
}

type SettingsView = 'MAIN' | 'DOWNLOAD_SETTINGS';

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, hideLogs = false, onSave, onDataRestored }) => {
  const [currentView, setCurrentView] = useState<SettingsView>('MAIN');

  const [uiOpacity, setUiOpacity] = useState(0.3);
  const [debugMode, setDebugMode] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  
  // Dropbox Folders
  const [tempUrlInput, setTempUrlInput] = useState(''); 
  const [hasConfiguredUrl, setHasConfiguredUrl] = useState(false); 
  
  // Last Update URL (NEW)
  const [tempUpdateUrl, setTempUpdateUrl] = useState('');
  
  // Proxy
  const [tempProxyInput, setTempProxyInput] = useState('');
  const [hasConfiguredProxy, setHasConfiguredProxy] = useState(false);
  const [isTestingProxy, setIsTestingProxy] = useState(false); // State per il loading del test

  const [lastBackup, setLastBackup] = useState<BackupInfo | null>(null);
  
  const [exportPreviewMode, setExportPreviewMode] = useState(false); 
  const [pendingFilename, setPendingFilename] = useState('');
  const [diskSaveConfirm, setDiskSaveConfirm] = useState<{filename: string} | null>(null);
  const [importConfirm, setImportConfirm] = useState<{name: string, content: string} | null>(null);

  const [showDbInspector, setShowDbInspector] = useState(false);
  const [inspectorContent, setInspectorContent] = useState('');
  const [inspectorCount, setInspectorCount] = useState(0);

  const [backupSuccess, setBackupSuccess] = useState<BackupSuccessState>({ isOpen: false, mode: 'EXPORT', filename: '', resultLabel: '' });
  
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [showUpdateUrlInput, setShowUpdateUrlInput] = useState(false); // New accordion
  const [showProxyInput, setShowProxyInput] = useState(false);
  const [showConsole, setShowConsole] = useState(false);
  
  const [showVisuals, setShowVisuals] = useState(false);
  const [showBackup, setShowBackup] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setShowBackup(false);
      setShowVisuals(false);
      setShowUrlInput(false);
      setShowUpdateUrlInput(false);
      setShowProxyInput(false);
      setShowConsole(false);
      setCurrentView('MAIN');

      const settings = loadSettings();
      
      const currentUrl = settings.folderUrl || '';
      setHasConfiguredUrl(currentUrl.trim().length > 0);
      setTempUrlInput(''); 

      setTempUpdateUrl(settings.lastUpdateUrl || '');

      const currentProxy = settings.customProxyUrl || '';
      setHasConfiguredProxy(currentProxy.trim().length > 0);
      setTempProxyInput(currentProxy); 

      setUiOpacity(settings.uiOpacity !== undefined ? settings.uiOpacity : 0.3);
      setDebugMode(settings.debugMode || false);
      setExportPreviewMode(false);
      setImportConfirm(null);
      setDiskSaveConfirm(null);
      setShowDbInspector(false);
      setIsTestingProxy(false);
      
      setLastBackup(getLastBackupInfo());

      if (!hideLogs) {
          setLogs(getLogs());
      }
    }
  }, [isOpen, hideLogs]);

  const handleSaveUrlOnly = () => {
      let url = tempUrlInput.trim();
      if (!url.startsWith('http')) {
          alert("Inserisci un link valido");
          return;
      }
      const currentSettings = loadSettings();
      const newSettings: AppSettings = { ...currentSettings, folderUrl: url };
      saveSettings(newSettings);
      setHasConfiguredUrl(true);
      setTempUrlInput(''); 
      alert("Link Dropbox salvato.");
  };

  const handleSaveUpdateUrlOnly = () => {
      const currentSettings = loadSettings();
      const newSettings: AppSettings = { ...currentSettings, lastUpdateUrl: tempUpdateUrl.trim() };
      saveSettings(newSettings);
      alert("Link Versione salvato.");
  };

  const handleSaveProxyOnly = () => {
      let proxy = tempProxyInput.trim();
      if (proxy.length > 0) {
          if (proxy.includes('@')) {
              alert("L'URL contiene una '@' (email?). Usa il link pubblico.");
              return;
          }
          if (!proxy.startsWith('http')) proxy = 'https://' + proxy;
      } else {
           alert("Inserisci un URL valido.");
           return;
      }

      const currentSettings = loadSettings();
      const newSettings: AppSettings = { ...currentSettings, customProxyUrl: proxy };
      saveSettings(newSettings);
      setHasConfiguredProxy(true);
      setTempProxyInput(proxy);
      alert("Proxy salvato.");
  };

  const handleTestProxy = async () => {
      const proxy = tempProxyInput.trim() || loadSettings().customProxyUrl;
      if (!proxy) {
          alert("Nessun proxy inserito.");
          return;
      }
      setIsTestingProxy(true);
      const res = await testProxyConnection(proxy);
      setIsTestingProxy(false);
      
      alert(res.msg);
  };
  
  const handleClearProxy = () => {
      const currentSettings = loadSettings();
      const newSettings: AppSettings = { ...currentSettings, customProxyUrl: '' };
      saveSettings(newSettings);
      setHasConfiguredProxy(false);
      setTempProxyInput('');
      alert("Proxy rimosso.");
  };

  const handleSave = () => {
    const currentSettings = loadSettings();
    
    let urlToSave = currentSettings.folderUrl;
    if (tempUrlInput.trim().startsWith('http')) urlToSave = tempUrlInput.trim();

    let proxyToSave = currentSettings.customProxyUrl;
    if (tempProxyInput.trim().length > 0) {
        let p = tempProxyInput.trim();
        if (!p.startsWith('http')) p = 'https://' + p;
        if (!p.includes('@')) proxyToSave = p;
    }

    const newSettings: AppSettings = { 
        folderUrl: urlToSave,
        lastUpdateUrl: tempUpdateUrl.trim(),
        customProxyUrl: proxyToSave,
        uiOpacity,
        debugMode
    };
    
    saveSettings(newSettings);
    if (onSave) onSave(newSettings);
    onClose();
  };

  const handleClearLogs = (e: React.MouseEvent) => {
      e.stopPropagation();
      clearLogs();
      setLogs([]);
  };

  // ... [INSPECTOR, EXPORT, IMPORT functions skipped for brevity - SAME AS BEFORE] ...
  // Re-declare for valid syntax within this block
  const handleOpenInspector = () => {
    const raw = localStorage.getItem(STORAGE_KEY_NOTE);
    if (!raw) { setInspectorContent("{}"); setInspectorCount(0); }
    else {
        try { const p = JSON.parse(raw); setInspectorCount(Object.keys(p).length); setInspectorContent(JSON.stringify(p, null, 2)); }
        catch (e) { setInspectorContent("Err"); }
    }
    setShowDbInspector(true);
  };
  const copyInspectorContent = async () => { await navigator.clipboard.writeText(inspectorContent); alert("Copiato"); };
  const handleExportSharePrepare = () => { setPendingFilename(`backup_${new Date().toISOString().split('T')[0]}.json`); setExportPreviewMode(true); };
  const handleExportShareExecute = async () => {
      const json = exportBackupData();
      const filename = pendingFilename;
      try {
        const res = await Filesystem.writeFile({ path: filename, data: json, directory: Directory.Cache, encoding: Encoding.UTF8 });
        await Share.share({ title: 'Backup', files: [res.uri] });
        saveLastBackupInfo(filename); setLastBackup(getLastBackupInfo()); setExportPreviewMode(false); setBackupSuccess({ isOpen: true, mode: 'EXPORT', filename, resultLabel: 'Condiviso' });
      } catch (e:any) { alert("Errore Export: " + e.message); }
  };
  const handleSaveDiskPrepare = () => { setDiskSaveConfirm({ filename: `backup_${new Date().toISOString().split('T')[0]}.json` }); };
  const handleSaveDiskExecute = async () => {
      if(!diskSaveConfirm) return;
      try {
          await Filesystem.writeFile({ path: diskSaveConfirm.filename, data: exportBackupData(), directory: Directory.Documents, encoding: Encoding.UTF8 });
          saveLastBackupInfo(diskSaveConfirm.filename); setLastBackup(getLastBackupInfo()); setDiskSaveConfirm(null); setBackupSuccess({ isOpen: true, mode: 'EXPORT', filename: diskSaveConfirm.filename, resultLabel: 'Salvato' });
      } catch(e:any) { alert("Errore: " + e.message); }
  };
  const decodeBase64 = (str: string) => {
    try { return new TextDecoder('utf-8').decode(Uint8Array.from(atob(str), c => c.charCodeAt(0))); } catch { return ""; }
  };
  const handleImportClick = async () => {
      try {
          const res = await FilePicker.pickFiles({ types: ['application/json'], readData: true });
          if(res.files[0]?.data) setImportConfirm({ name: res.files[0].name, content: decodeBase64(res.files[0].data) });
      } catch {}
  };
  const handleExecuteImport = () => {
      if(!importConfirm) return;
      if(importBackupData(importConfirm.content)) {
           const s = loadSettings(); setUiOpacity(s.uiOpacity||0.3); setDebugMode(s.debugMode||false); setHasConfiguredUrl(!!s.folderUrl); setHasConfiguredProxy(!!s.customProxyUrl); setTempUpdateUrl(s.lastUpdateUrl||'');
           if(onSave) onSave(s); if(onDataRestored) onDataRestored();
           setBackupSuccess({ isOpen: true, mode: 'IMPORT', filename: importConfirm.name, resultLabel: 'Successo' });
      } else alert("Backup non valido");
      setImportConfirm(null);
  };


  const showLinkSaveButton = tempUrlInput.trim().toLowerCase().startsWith('http');
  const showProxySaveButton = tempProxyInput.trim().length > 0;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      {/* SUCCESS/CONFIRM MODALS OMITTED FOR BREVITY, ASSUME THEY ARE HERE */}
      
      <div className="bg-slate-900 border border-slate-700 w-full max-w-sm rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-800/50">
          <div className="flex items-center gap-2 text-white">
            {currentView === 'MAIN' ? (
                <> <LinkIcon className="w-5 h-5 text-emerald-500" /> <h2 className="text-lg font-bold">Configurazione</h2> </>
            ) : (
                <button onClick={() => setCurrentView('MAIN')} className="flex items-center gap-1 text-slate-300 hover:text-white transition-colors"> <ArrowLeft className="w-5 h-5" /> <h2 className="text-lg font-bold">Download Settings</h2> </button>
            )}
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors"><X className="w-6 h-6" /></button>
        </div>

        <div className="p-4 flex flex-col gap-4 overflow-y-auto">
          {currentView === 'MAIN' && (
              <>
                  {/* BACKUP & VISUALS ACCORDIONS (SAME AS BEFORE) */}
                  <div className="flex flex-col gap-2">
                      <button onClick={() => setShowBackup(!showBackup)} className="flex items-center justify-between w-full p-3 bg-slate-800/50 rounded-lg border border-slate-700/50 text-slate-300 font-medium text-sm">
                          <div className="flex items-center gap-2"><Database className="w-4 h-4 text-blue-400" />Backup & Ripristino</div>{showBackup ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                      </button>
                      {showBackup && (
                        <div className="space-y-3 p-3 bg-slate-950/30 rounded border border-slate-800/50">
                             {!exportPreviewMode ? (
                                <>
                                    <div className="flex gap-2">
                                        <button onClick={handleExportSharePrepare} className="flex-1 bg-slate-800 border border-slate-700 p-2 rounded-lg text-[10px] text-slate-300">Condividi</button>
                                        <button onClick={handleSaveDiskPrepare} className="flex-1 bg-slate-800 border border-slate-700 p-2 rounded-lg text-[10px] text-slate-300">Salva Disco</button>
                                        <button onClick={handleImportClick} className="flex-1 bg-slate-800 border border-slate-700 p-2 rounded-lg text-[10px] text-slate-300">Importa</button>
                                    </div>
                                    <button onClick={handleOpenInspector} className="w-full py-1.5 border border-slate-700 rounded text-slate-500 text-[10px] mt-2">DB Inspector</button>
                                </>
                             ) : (
                                <div className="text-center text-slate-400 text-xs">
                                     <p>Confermi export?</p>
                                     <div className="flex gap-2 mt-2"><button onClick={()=>setExportPreviewMode(false)} className="flex-1 py-2 border rounded">No</button><button onClick={handleExportShareExecute} className="flex-1 py-2 bg-emerald-600 text-white rounded">Si</button></div>
                                </div>
                             )}
                        </div>
                      )}
                  </div>

                  <div className="flex flex-col gap-2">
                      <button onClick={() => setShowVisuals(!showVisuals)} className="flex items-center justify-between w-full p-3 bg-slate-800/50 rounded-lg border border-slate-700/50 text-slate-300 font-medium text-sm">
                          <div className="flex items-center gap-2"><Sliders className="w-4 h-4 text-emerald-400" />Aspetto</div>{showVisuals ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                      </button>
                      {showVisuals && ( <div className="p-3 bg-slate-950/30 rounded border border-slate-800/50"> <input type="range" min="0" max="1" step="0.05" value={uiOpacity} onChange={(e) => setUiOpacity(parseFloat(e.target.value))} className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"/> </div> )}
                  </div>

                  <button onClick={() => setCurrentView('DOWNLOAD_SETTINGS')} className="flex items-center justify-between w-full p-3 bg-slate-800/50 rounded-lg border border-slate-700/50 text-slate-300 font-medium text-sm">
                      <div className="flex items-center gap-2"><CloudCog className="w-4 h-4 text-purple-400" />Index Download</div><ChevronRight className="w-4 h-4 text-slate-500" />
                  </button>
              </>
          )}

          {currentView === 'DOWNLOAD_SETTINGS' && (
              <div className="flex flex-col gap-4">
                  {/* DROPBOX FOLDER */}
                  <div className="flex flex-col gap-2">
                      <button onClick={() => setShowUrlInput(!showUrlInput)} className="flex items-center justify-between w-full p-3 bg-slate-800/50 rounded-lg border border-slate-700/50 text-slate-300 font-medium text-sm">
                          <div className="flex items-center gap-2"><FolderOpen className="w-4 h-4 text-emerald-400" />Cartella Dropbox</div>{showUrlInput ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                      </button>
                      {showUrlInput && (
                        <div className="space-y-3 p-2 bg-slate-950/30 rounded border border-slate-800/50">
                            <div className="flex justify-between px-1 text-[11px] text-slate-400"><span>Stato:</span>{hasConfiguredUrl ? <span className="text-emerald-400 font-bold">Configurato</span> : <span className="text-red-400">Mancante</span>}</div>
                            <div className="relative"><textarea value={tempUrlInput} onChange={(e) => setTempUrlInput(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-xs text-slate-200 h-16 resize-none" placeholder="https://dropbox.com/scl/fo/..."/>{showLinkSaveButton && (<button onClick={handleSaveUrlOnly} className="absolute bottom-2 right-2 bg-emerald-600 text-white px-2 py-1 rounded text-[10px]">Salva</button>)}</div>
                        </div>
                      )}
                  </div>

                  {/* LAST UPDATE URL (NEW) */}
                  <div className="flex flex-col gap-2">
                      <button onClick={() => setShowUpdateUrlInput(!showUpdateUrlInput)} className="flex items-center justify-between w-full p-3 bg-slate-800/50 rounded-lg border border-slate-700/50 text-slate-300 font-medium text-sm">
                          <div className="flex items-center gap-2"><FileText className="w-4 h-4 text-sky-400" />File Versione (Opzionale)</div>{showUpdateUrlInput ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                      </button>
                      {showUpdateUrlInput && (
                        <div className="space-y-3 p-2 bg-slate-950/30 rounded border border-slate-800/50 animate-in fade-in slide-in-from-top-2">
                            <p className="text-[10px] text-slate-500 leading-tight">Link diretto a <b>Last_Update.txt</b>. Se presente, l'app scaricherà solo questo file per controllare gli aggiornamenti.</p>
                            <div className="flex flex-col gap-2">
                                <input type="text" value={tempUpdateUrl} onChange={(e) => setTempUpdateUrl(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-xs text-slate-200 font-mono" placeholder="https://dropbox.com/.../Last_Update.txt?dl=1" />
                                <button onClick={handleSaveUpdateUrlOnly} className="self-end bg-sky-600 hover:bg-sky-500 text-white px-3 py-1.5 rounded text-xs font-bold">Salva Link Versione</button>
                            </div>
                        </div>
                      )}
                  </div>

                  {/* PROXY */}
                  <div className="flex flex-col gap-2">
                      <button onClick={() => setShowProxyInput(!showProxyInput)} className="flex items-center justify-between w-full p-3 bg-slate-800/50 rounded-lg border border-slate-700/50 text-slate-300 font-medium text-sm">
                          <div className="flex items-center gap-2"><Network className="w-4 h-4 text-purple-400" />Proxy Cloudflare</div>{showProxyInput ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                      </button>
                      {showProxyInput && (
                        <div className="space-y-3 p-2 bg-slate-950/30 rounded border border-slate-800/50">
                             <div className="flex justify-between px-1 text-[11px] text-slate-400"><span>Stato:</span>{hasConfiguredProxy ? <span className="text-emerald-400">Attivo</span> : <span>Default</span>}</div>
                             <input type="text" value={tempProxyInput} onChange={(e) => setTempProxyInput(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-xs text-slate-200 font-mono" placeholder="https://worker.dev" />
                             <div className="flex justify-end gap-2 items-center">
                                 {/* TEST PROXY BUTTON */}
                                 <button onClick={handleTestProxy} disabled={isTestingProxy} className="flex items-center gap-1 bg-slate-700 text-slate-300 px-3 py-1.5 rounded text-xs border border-slate-600 hover:bg-slate-600">
                                     {isTestingProxy ? <Activity className="w-3 h-3 animate-spin text-yellow-400" /> : <Activity className="w-3 h-3" />} Test
                                 </button>
                                 {showProxySaveButton && (<button onClick={handleSaveProxyOnly} className="bg-purple-600 text-white px-3 py-1.5 rounded text-xs font-bold">Salva</button>)}
                             </div>
                        </div>
                      )}
                  </div>
                  
                  {/* LOGS */}
                  {!hideLogs && (
                    <div className="flex flex-col gap-2">
                        <button onClick={() => setShowConsole(!showConsole)} className="flex items-center justify-between w-full p-3 bg-slate-800/50 rounded-lg border border-slate-700/50 text-slate-300 font-medium text-sm">
                            <div className="flex items-center gap-2"><Terminal className="w-4 h-4 text-orange-400" />Log Sistema</div>{showConsole ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                        </button>
                        {showConsole && (
                            <div className="flex flex-col gap-2">
                                <div className="w-full bg-black border border-slate-800 rounded p-2 text-[10px] text-green-400 font-mono h-40 overflow-y-auto">{logs.map((l,i)=><div key={i}>{l}</div>)}</div>
                                <div className="flex justify-between p-2 bg-slate-950/50 rounded border border-slate-800"><label className="flex items-center gap-2 text-xs text-slate-400"><input type="checkbox" checked={debugMode} onChange={e=>setDebugMode(e.target.checked)} className="accent-red-500"/>Debug</label><button onClick={handleClearLogs} className="text-xs text-red-400 border border-slate-700 px-2 py-1 rounded">Clear</button></div>
                            </div>
                        )}
                    </div>
                  )}
              </div>
          )}
        </div>
        
        <div className="p-4 border-t border-slate-800 bg-slate-800/30 flex justify-end">
          <button onClick={handleSave} className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg font-medium transition-colors text-sm">
            <Save className="w-4 h-4" /> Salva & Chiudi
          </button>
        </div>
      </div>
    </div>
  );
};